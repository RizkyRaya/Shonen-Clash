package
{
   import flash.compiler.embed.EmbeddedMovieClip;
   
   public class §dialog_ui_swf$03d38cc11a1612d10e1b93f1f9bb80f7-1993337248§ extends EmbeddedMovieClip
   {
      
      public function §dialog_ui_swf$03d38cc11a1612d10e1b93f1f9bb80f7-1993337248§()
      {
         super(new §dialog_ui_swf$03d38cc11a1612d10e1b93f1f9bb80f7-1993337248ByteArray§(),800,600);
      }
   }
}


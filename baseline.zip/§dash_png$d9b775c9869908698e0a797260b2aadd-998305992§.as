package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/8_dash_png$d9b775c9869908698e0a797260b2aadd-998305992.png")]
   public class §dash_png$d9b775c9869908698e0a797260b2aadd-998305992§ extends Bitmap
   {
      
      public function §dash_png$d9b775c9869908698e0a797260b2aadd-998305992§()
      {
         super();
      }
   }
}


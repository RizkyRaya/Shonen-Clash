package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/18_spskill_png$da02163ba059a465ff55507e8f118c3b-128022780.png")]
   public class §spskill_png$da02163ba059a465ff55507e8f118c3b-128022780§ extends Bitmap
   {
      
      public function §spskill_png$da02163ba059a465ff55507e8f118c3b-128022780§()
      {
         super();
      }
   }
}


package
{
   import flash.compiler.embed.EmbeddedMovieClip;
   
   public class §common_ui_swf$fa8c50f0c229a548cd53218b6f64f0d9-2091959187§ extends EmbeddedMovieClip
   {
      
      public function §common_ui_swf$fa8c50f0c229a548cd53218b6f64f0d9-2091959187§()
      {
         super(new §common_ui_swf$fa8c50f0c229a548cd53218b6f64f0d9-2091959187ByteArray§(),800,600);
      }
   }
}


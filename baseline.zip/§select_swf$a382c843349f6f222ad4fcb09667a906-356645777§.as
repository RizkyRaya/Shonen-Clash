package
{
   import flash.compiler.embed.EmbeddedMovieClip;
   
   public class §select_swf$a382c843349f6f222ad4fcb09667a906-356645777§ extends EmbeddedMovieClip
   {
      
      public function §select_swf$a382c843349f6f222ad4fcb09667a906-356645777§()
      {
         super(new §select_swf$a382c843349f6f222ad4fcb09667a906-356645777ByteArray§(),800,600);
      }
   }
}


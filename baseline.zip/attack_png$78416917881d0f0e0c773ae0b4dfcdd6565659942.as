package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/15_attack_png$78416917881d0f0e0c773ae0b4dfcdd6565659942.png")]
   public class attack_png$78416917881d0f0e0c773ae0b4dfcdd6565659942 extends Bitmap
   {
      
      public function attack_png$78416917881d0f0e0c773ae0b4dfcdd6565659942()
      {
         super();
      }
   }
}


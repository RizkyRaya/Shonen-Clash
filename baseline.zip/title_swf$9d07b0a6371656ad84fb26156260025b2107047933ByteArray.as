package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/37_title_swf$9d07b0a6371656ad84fb26156260025b2107047933ByteArray.bin", mimeType="application/octet-stream")]
   public class title_swf$9d07b0a6371656ad84fb26156260025b2107047933ByteArray extends ByteArray
   {
      
      public function title_swf$9d07b0a6371656ad84fb26156260025b2107047933ByteArray()
      {
         super();
      }
   }
}


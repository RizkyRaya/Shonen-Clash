package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/28_loading_swf$05a8dab2aa9490e41daf78e885c1980c976431505ByteArray.bin", mimeType="application/octet-stream")]
   public class loading_swf$05a8dab2aa9490e41daf78e885c1980c976431505ByteArray extends ByteArray
   {
      
      public function loading_swf$05a8dab2aa9490e41daf78e885c1980c976431505ByteArray()
      {
         super();
      }
   }
}


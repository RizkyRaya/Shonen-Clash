package
{
   import flash.compiler.embed.EmbeddedMovieClip;
   
   public class bigmap_swf$a97606add711bb2a60a61a369b696ac6508782799 extends EmbeddedMovieClip
   {
      
      public function bigmap_swf$a97606add711bb2a60a61a369b696ac6508782799()
      {
         super(new bigmap_swf$a97606add711bb2a60a61a369b696ac6508782799ByteArray(),800,600);
      }
   }
}


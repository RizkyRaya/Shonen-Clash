package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/38_setting_joy_png$c33d2c1ee246601fc37f0ef734be9588-682700004.png")]
   public class §setting_joy_png$c33d2c1ee246601fc37f0ef734be9588-682700004§ extends Bitmap
   {
      
      public function §setting_joy_png$c33d2c1ee246601fc37f0ef734be9588-682700004§()
      {
         super();
      }
   }
}


package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/17_skill_png$8d9e86fd18d314108f3c0b8a3728de1b-392362231.png")]
   public class §skill_png$8d9e86fd18d314108f3c0b8a3728de1b-392362231§ extends Bitmap
   {
      
      public function §skill_png$8d9e86fd18d314108f3c0b8a3728de1b-392362231§()
      {
         super();
      }
   }
}


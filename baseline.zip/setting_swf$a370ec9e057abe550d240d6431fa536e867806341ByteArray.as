package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/31_setting_swf$a370ec9e057abe550d240d6431fa536e867806341ByteArray.bin", mimeType="application/octet-stream")]
   public class setting_swf$a370ec9e057abe550d240d6431fa536e867806341ByteArray extends ByteArray
   {
      
      public function setting_swf$a370ec9e057abe550d240d6431fa536e867806341ByteArray()
      {
         super();
      }
   }
}


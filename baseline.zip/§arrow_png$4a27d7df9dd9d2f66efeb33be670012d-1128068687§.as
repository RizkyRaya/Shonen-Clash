package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/16_arrow_png$4a27d7df9dd9d2f66efeb33be670012d-1128068687.png")]
   public class §arrow_png$4a27d7df9dd9d2f66efeb33be670012d-1128068687§ extends Bitmap
   {
      
      public function §arrow_png$4a27d7df9dd9d2f66efeb33be670012d-1128068687§()
      {
         super();
      }
   }
}


package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/26_gameover_swf$76a5c9359b37caf59810585482d8d6fb-674241051ByteArray.bin", mimeType="application/octet-stream")]
   public class §gameover_swf$76a5c9359b37caf59810585482d8d6fb-674241051ByteArray§ extends ByteArray
   {
      
      public function §gameover_swf$76a5c9359b37caf59810585482d8d6fb-674241051ByteArray§()
      {
         super();
      }
   }
}


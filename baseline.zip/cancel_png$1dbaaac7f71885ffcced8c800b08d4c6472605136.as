package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/19_cancel_png$1dbaaac7f71885ffcced8c800b08d4c6472605136.png")]
   public class cancel_png$1dbaaac7f71885ffcced8c800b08d4c6472605136 extends Bitmap
   {
      
      public function cancel_png$1dbaaac7f71885ffcced8c800b08d4c6472605136()
      {
         super();
      }
   }
}


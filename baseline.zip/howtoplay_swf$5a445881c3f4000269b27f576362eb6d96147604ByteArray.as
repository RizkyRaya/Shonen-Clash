package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/27_howtoplay_swf$5a445881c3f4000269b27f576362eb6d96147604ByteArray.bin", mimeType="application/octet-stream")]
   public class howtoplay_swf$5a445881c3f4000269b27f576362eb6d96147604ByteArray extends ByteArray
   {
      
      public function howtoplay_swf$5a445881c3f4000269b27f576362eb6d96147604ByteArray()
      {
         super();
      }
   }
}


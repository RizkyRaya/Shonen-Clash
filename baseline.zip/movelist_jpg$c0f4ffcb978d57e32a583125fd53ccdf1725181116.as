package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/39_movelist_jpg$c0f4ffcb978d57e32a583125fd53ccdf1725181116.png")]
   public class movelist_jpg$c0f4ffcb978d57e32a583125fd53ccdf1725181116 extends Bitmap
   {
      
      public function movelist_jpg$c0f4ffcb978d57e32a583125fd53ccdf1725181116()
      {
         super();
      }
   }
}


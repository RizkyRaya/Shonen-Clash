package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/3_side_bg_png$fc34be3195826d9ab5147ae09371965e1587633748.png")]
   public class side_bg_png$fc34be3195826d9ab5147ae09371965e1587633748 extends Bitmap
   {
      
      public function side_bg_png$fc34be3195826d9ab5147ae09371965e1587633748()
      {
         super();
      }
   }
}


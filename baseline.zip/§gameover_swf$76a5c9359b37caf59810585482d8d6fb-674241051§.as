package
{
   import flash.compiler.embed.EmbeddedMovieClip;
   
   public class §gameover_swf$76a5c9359b37caf59810585482d8d6fb-674241051§ extends EmbeddedMovieClip
   {
      
      public function §gameover_swf$76a5c9359b37caf59810585482d8d6fb-674241051§()
      {
         super(new §gameover_swf$76a5c9359b37caf59810585482d8d6fb-674241051ByteArray§(),800,600);
      }
   }
}


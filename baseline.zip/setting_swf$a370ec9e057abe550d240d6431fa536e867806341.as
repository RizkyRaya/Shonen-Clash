package
{
   import flash.compiler.embed.EmbeddedMovieClip;
   
   public class setting_swf$a370ec9e057abe550d240d6431fa536e867806341 extends EmbeddedMovieClip
   {
      
      public function setting_swf$a370ec9e057abe550d240d6431fa536e867806341()
      {
         super(new setting_swf$a370ec9e057abe550d240d6431fa536e867806341ByteArray(),800,600);
      }
   }
}


package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/20_pause_png$6c4859e4660e5aec0769847311b8267b777651238.png")]
   public class pause_png$6c4859e4660e5aec0769847311b8267b777651238 extends Bitmap
   {
      
      public function pause_png$6c4859e4660e5aec0769847311b8267b777651238()
      {
         super();
      }
   }
}


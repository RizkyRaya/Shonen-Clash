package
{
   import flash.compiler.embed.EmbeddedMovieClip;
   
   public class mosou_swf$8aafc481e7d4471f7c6efdb597320ca0588557020 extends EmbeddedMovieClip
   {
      
      public function mosou_swf$8aafc481e7d4471f7c6efdb597320ca0588557020()
      {
         super(new mosou_swf$8aafc481e7d4471f7c6efdb597320ca0588557020ByteArray(),800,600);
      }
   }
}


package net.play5d.kyo.utils
{
   import flash.net.LocalConnection;
   import flash.system.System;
   import net.play5d.game.bvn.ctrl.EffectCtrl;
   import net.play5d.game.bvn.ctrl.GameLoader;
   import net.play5d.game.bvn.ctrl.ShadowCtrl;
   import net.play5d.game.bvn.ctrl.game_stage_loader.GameStageLoadCtrl;
   import net.play5d.game.bvn.fighter.FighterMain;
   import net.play5d.game.bvn.mob.AssetLoader;
   import net.play5d.game.bvn.views.effects.BitmapFilterView;
   import net.play5d.game.bvn.views.effects.ShadowEffectView;
   
   public class MemoryCleaner
   {
      
      public function MemoryCleaner()
      {
         super();
      }
      
      public static function cleanUp(fighters:Array = null) : void
      {
         try
         {
            cleanFighters(fighters);
            try
            {
               ShadowEffectView.clearPool();
            }
            catch(e:Error)
            {
            }
            try
            {
               BitmapFilterView.clearPool();
            }
            catch(e:Error)
            {
            }
            try
            {
               GameLoader.dispose();
            }
            catch(e:Error)
            {
            }
            try
            {
               GameStageLoadCtrl.I.dispose();
            }
            catch(e:Error)
            {
            }
            try
            {
               ShadowCtrl.clear();
            }
            catch(e:Error)
            {
            }
            try
            {
               if(EffectCtrl.I != null)
               {
                  EffectCtrl.I.destory();
               }
            }
            catch(e:Error)
            {
            }
            try
            {
               AssetLoader.clearCache();
            }
            catch(e:Error)
            {
            }
         }
         catch(e:Error)
         {
            trace("MemoryCleaner.cleanUp Error: " + e.message);
         }
         finally
         {
            forceGC();
         }
      }
      
      public static function cleanFighters(fighters:Array) : void
      {
         var item:*;
         var fighter:FighterMain;
         if(!fighters)
         {
            return;
         }
         for each(item in fighters)
         {
            try
            {
               if(item is FighterMain)
               {
                  fighter = item as FighterMain;
                  if(fighter != null)
                  {
                     fighter.destory(true);
                  }
               }
            }
            catch(e:Error)
            {
               trace("MemoryCleaner.cleanFighters Error: " + e.message);
            }
         }
      }
      
      private static function forceGC() : void
      {
         var lc1:LocalConnection;
         var lc2:LocalConnection;
         System.gc();
         try
         {
            lc1 = new LocalConnection();
            lc2 = new LocalConnection();
            lc1.connect("bvn_ram_cleaner_gc");
            lc2.connect("bvn_ram_cleaner_gc");
         }
         catch(e:Error)
         {
         }
      }
   }
}


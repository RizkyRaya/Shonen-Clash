package net.play5d.kyo.display.bitmap
{
   import flash.display.Bitmap;
   import flash.display.BitmapData;
   import flash.events.Event;
   import net.play5d.kyo.loader.BitmapLoader;
   import net.play5d.kyo.loader.KyoURLoader;
   
   public class BitmapFontLoader
   {
      
      private var _urls:Array;
      
      private var _fontObj:Object = {};
      
      private var _loadAmount:int;
      
      private var _loadBack:Function;
      
      private var _loadProcess:Function;
      
      public function BitmapFontLoader()
      {
         super();
      }
      
      public function clear() : void
      {
         if(this._fontObj)
         {
            for(var fontName in this._fontObj)
            {
               var font:Object = this._fontObj[fontName];
               if(font)
               {
                  if(font.hasOwnProperty("dispose") && font["dispose"] is Function)
                  {
                     font["dispose"]();
                  }
                  else if(font.hasOwnProperty("bitmapData") && font["bitmapData"] is BitmapData)
                  {
                     (font["bitmapData"] as BitmapData).dispose();
                  }
               }
               delete this._fontObj[fontName];
            }
         }
         this._fontObj = {};
      }
      
      public function loadFonts(urlList:Array, onComplete:Function = null, onProcess:Function = null) : void
      {
         this._loadBack = onComplete;
         this._loadProcess = onProcess;
         this._urls = urlList ? urlList.concat() : [];
         this._loadAmount = this._urls.length;
         this.loadNext();
      }
      
      public function loadFont(xmlUrl:String, xmlData:XML, onComplete:Function = null, onFail:Function = null) : void
      {
         var pageFile:String = xmlData.pages.page.@file;
         var folderPath:String = xmlUrl.substr(0,xmlUrl.lastIndexOf("/") + 1);
         var bitmapUrl:String = folderPath + pageFile;
         this.loadBitmapData(bitmapUrl,xmlData,onComplete,onFail);
      }
      
      public function addFont(xmlData:XML, bmd:BitmapData) : void
      {
         var faceName:String = xmlData.info.@face;
         this._fontObj[faceName] = new BitmapFont(xmlData,bmd);
      }
      
      public function getFont(fontName:String) : BitmapFont
      {
         return this._fontObj[fontName];
      }
      
      private function loadComplete() : void
      {
         if(this._loadBack != null)
         {
            var callback:Function = this._loadBack;
            this._loadBack = null;
            callback();
         }
         this._loadProcess = null;
      }
      
      private function loadNext() : void
      {
         var url:String = null;
         var loadXMLFin:Function = null;
         var loadXMLFail:Function = null;
         var cur:int = 0;
         loadXMLFin = function(xmlText:String):void
         {
            var xml:XML = new XML(xmlText);
            var pageFile:String = xml.pages.page.@file;
            var folderPath:String = url.substr(0,url.lastIndexOf("/") + 1);
            var bitmapUrl:String = folderPath + pageFile;
            loadBitmapData(bitmapUrl,xml,loadNext,loadNext);
            loadXMLFin = null;
            loadXMLFail = null;
         };
         loadXMLFail = function():void
         {
            trace("BitmapFontLoader.loadXMLFail::" + url);
            loadNext();
            loadXMLFin = null;
            loadXMLFail = null;
         };
         if(this._loadProcess != null)
         {
            cur = this._loadAmount - this._urls.length;
            this._loadProcess(cur / this._loadAmount);
         }
         if(this._urls.length < 1)
         {
            this.loadComplete();
            return;
         }
         url = this._urls.shift();
         KyoURLoader.load(url,loadXMLFin,loadXMLFail);
      }
      
      private function loadBitmapData(bpurl:String, xml:XML, back:Function = null, fail:Function = null) : void
      {
         var fontid:String = xml.info.@face;
         var loadBpComplete:Function = null;
         var loadBpFail:Function = null;
         loadBpComplete = function(bmp:Bitmap):void
         {
            if(bmp && bmp.bitmapData)
            {
               _fontObj[fontid] = new BitmapFont(xml,bmp.bitmapData);
            }
            if(back != null)
            {
               back();
            }
            loadBpComplete = null;
            loadBpFail = null;
         };
         loadBpFail = function(e:Event = null):void
         {
            trace("BitmapFontLoader.loadBpFail::" + bpurl);
            if(fail != null)
            {
               fail();
            }
            loadBpComplete = null;
            loadBpFail = null;
         };
         var loader:BitmapLoader = new BitmapLoader();
         loader.load(bpurl,loadBpComplete,loadBpFail);
      }
   }
}


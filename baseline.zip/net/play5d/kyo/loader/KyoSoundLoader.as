package net.play5d.kyo.loader
{
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.ProgressEvent;
   import flash.events.TimerEvent;
   import flash.media.Sound;
   import flash.net.URLLoader;
   import flash.net.URLRequest;
   import flash.utils.Timer;
   
   public class KyoSoundLoader
   {
      
      private var _urls:Array;
      
      private var _curUrl:String;
      
      private var _soundObj:Object = {};
      
      private var _loadBack:Function;
      
      private var _loadProcess:Function;
      
      private var _loadLength:int;
      
      private var _curSound:Sound;
      
      private var _timeoutTimer:Timer;
      
      private var _retryCount:int = 0;
      
      private const MAX_RETRY:int = 3;
      
      public function KyoSoundLoader()
      {
         super();
         _timeoutTimer = new Timer(10000,1);
         _timeoutTimer.addEventListener(TimerEvent.TIMER_COMPLETE,onTimeout);
      }
      
      public function unload() : void
      {
         var snd:Sound = null;
         if(_timeoutTimer)
         {
            _timeoutTimer.stop();
         }
         if(_curSound)
         {
            removeListeners(_curSound);
            try
            {
               _curSound.close();
            }
            catch(e:Error)
            {
            }
            _curSound = null;
         }
         if(this._soundObj)
         {
            for each(snd in this._soundObj)
            {
               try
               {
                  snd.close();
               }
               catch(e:Error)
               {
               }
            }
            this._soundObj = {};
         }
      }
      
      public function loadSounds(param1:Array, param2:Function = null, param3:Function = null) : void
      {
         this._loadBack = param2;
         this._loadProcess = param3;
         this._urls = param1.concat();
         this._loadLength = param1.length;
         this.loadNext();
      }
      
      public function getSound(param1:String) : Sound
      {
         var key:String = null;
         var fileName:String = null;
         if(this._soundObj[param1])
         {
            return this._soundObj[param1];
         }
         for(key in this._soundObj)
         {
            fileName = key.substr(key.lastIndexOf("/") + 1);
            fileName = fileName.substr(0,fileName.lastIndexOf("."));
            if(fileName == param1)
            {
               return this._soundObj[key];
            }
         }
         return null;
      }
      
      public function addSound(param1:String, param2:Sound) : void
      {
         this._soundObj[param1] = param2;
      }
      
      private function loadNext() : void
      {
         if(this._urls.length == 0)
         {
            this.loadFin();
            return;
         }
         this._curUrl = this._urls.shift();
         this._retryCount = 0;
         this.startLoad();
      }
      
      private function startLoad() : void
      {
         _curSound = new Sound(new URLRequest(this._curUrl));
         _curSound.addEventListener(Event.COMPLETE,this.loadCom);
         _curSound.addEventListener(ProgressEvent.PROGRESS,this.loadProcessHandler);
         _curSound.addEventListener(IOErrorEvent.IO_ERROR,this.loadErr);
         _timeoutTimer.reset();
         _timeoutTimer.start();
      }
      
      private function removeListeners(snd:Sound) : void
      {
         if(!snd)
         {
            return;
         }
         snd.removeEventListener(Event.COMPLETE,this.loadCom);
         snd.removeEventListener(ProgressEvent.PROGRESS,this.loadProcessHandler);
         snd.removeEventListener(IOErrorEvent.IO_ERROR,this.loadErr);
      }
      
      private function onTimeout(e:TimerEvent) : void
      {
         trace("KyoSoundLoader :: Timeout terdeteksi pada muatan: " + _curUrl);
         removeListeners(_curSound);
         try
         {
            _curSound.close();
         }
         catch(err:Error)
         {
         }
         ++_retryCount;
         if(_retryCount <= MAX_RETRY)
         {
            trace("KyoSoundLoader :: Mencoba ulang... (" + _retryCount + "/" + MAX_RETRY + ")");
            startLoad();
         }
         else
         {
            trace("KyoSoundLoader :: Gagal setelah batas maksimal retry: " + _curUrl);
            _curSound = null;
            if(this._urls.length < 1)
            {
               this.loadFin();
            }
            else
            {
               this.loadNext();
            }
         }
      }
      
      private function loadProcessHandler(param1:ProgressEvent) : void
      {
         _timeoutTimer.reset();
         _timeoutTimer.start();
         var percent:Number = Number(NaN);
         var totalPercent:Number = Number(NaN);
         var finalProgress:Number = Number(NaN);
         if(this._loadProcess != null)
         {
            percent = param1.bytesLoaded / param1.bytesTotal;
            totalPercent = this._loadLength - this._urls.length - 1 + percent;
            finalProgress = totalPercent / this._loadLength;
            this._loadProcess(finalProgress);
         }
      }
      
      private function loadCom(param1:Event) : void
      {
         _timeoutTimer.stop();
         var snd:Sound = param1.currentTarget as Sound;
         removeListeners(snd);
         this._soundObj[this._curUrl] = snd;
         this._curSound = null;
         if(this._urls.length < 1)
         {
            this.loadFin();
         }
         else
         {
            this.loadNext();
         }
      }
      
      private function loadErr(param1:IOErrorEvent) : void
      {
         _timeoutTimer.stop();
         var snd:Sound = param1.currentTarget as Sound;
         removeListeners(snd);
         trace("KyoSoundLoader.loadErr :: Gagal memuat suara : " + snd.url);
         this._curSound = null;
         if(this._urls.length < 1)
         {
            this.loadFin();
         }
         else
         {
            this.loadNext();
         }
      }
      
      private function loadFin() : void
      {
         _timeoutTimer.stop();
         if(this._loadBack != null)
         {
            this._loadBack();
            this._loadBack = null;
            this._loadProcess = null;
         }
      }
      
      public function loadPath(param1:String, param2:String, param3:Function = null) : void
      {
         var l:URLLoader = null;
         var path:String = param1;
         var listXML:String = param2;
         var back:Function = param3;
         l = new URLLoader(new URLRequest(path + "/" + listXML));
         var onComplete:Function = function(param1:Event):void
         {
            l.removeEventListener(Event.COMPLETE,onComplete);
            var child:Object = null;
            var xmlData:XML = new XML(l.data);
            var queue:Array = [];
            for each(child in xmlData.children())
            {
               queue.push(path + "/" + child.toString());
            }
            loadSounds(queue,back);
            onComplete = null;
            back = null;
            l = null;
         };
         l.addEventListener(Event.COMPLETE,onComplete);
      }
   }
}


package net.play5d.kyo.loader
{
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.SecurityErrorEvent;
   import flash.net.URLLoader;
   import flash.net.URLRequest;
   import flash.net.URLRequestMethod;
   import flash.net.URLVariables;
   import flash.utils.ByteArray;
   
   public class KyoURLoader
   {
      
      public static var errorStr:String;
      
      public static var showDebug:Boolean = true;
      
      public static const TYPE_UNICODE:String = "Unicode";
      
      public static const TYPE_UNICODE_BIG_ENDIAN:String = "Unicode big endian";
      
      public static const TYPE_UTF8:String = "UTF-8";
      
      public static const TYPE_ANSI:String = "ANSI";
      
      public function KyoURLoader()
      {
         super();
      }
      
      public static function load(url:String, onComplete:Function, onFail:Function = null, params:Object = null) : void
      {
         var key:String;
         var loadComplete:Function;
         var ioError:Function;
         var securityError:Function;
         var clear:Function;
         var loader:URLLoader = new URLLoader();
         errorStr = null;
         if(params)
         {
            for(key in params)
            {
               loader[key] = params[key];
            }
         }
         loadComplete = null;
         ioError = null;
         securityError = null;
         clear = null;
         clear = function():void
         {
            loader.removeEventListener(Event.COMPLETE,loadComplete);
            loader.removeEventListener(IOErrorEvent.IO_ERROR,ioError);
            loader.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,securityError);
            loader = null;
            loadComplete = null;
            ioError = null;
            securityError = null;
            clear = null;
            onComplete = null;
            onFail = null;
         };
         loadComplete = function(e:Event):void
         {
            if(onComplete != null)
            {
               onComplete(loader.data);
            }
            clear();
         };
         ioError = function(e:IOErrorEvent):void
         {
            errorStr = e.toString();
            if(showDebug)
            {
               trace("KyoURLoader.load IO_ERROR:",url,"\n",errorStr);
            }
            if(onFail != null)
            {
               onFail();
            }
            clear();
         };
         securityError = function(e:SecurityErrorEvent):void
         {
            errorStr = e.toString();
            if(showDebug)
            {
               trace("KyoURLoader.load SECURITY_ERROR:",url,"\n",errorStr);
            }
            if(onFail != null)
            {
               onFail();
            }
            clear();
         };
         loader.addEventListener(Event.COMPLETE,loadComplete);
         loader.addEventListener(IOErrorEvent.IO_ERROR,ioError);
         loader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,securityError);
         loader.load(new URLRequest(url));
      }
      
      public static function post(url:String, data:Object, onComplete:Function = null, onFail:Function = null) : void
      {
         var uv:URLVariables;
         var key:String;
         var loadComplete:Function;
         var ioError:Function;
         var securityError:Function;
         var clear:Function;
         var loader:URLLoader = new URLLoader();
         var uq:URLRequest = new URLRequest(url);
         uq.method = URLRequestMethod.POST;
         if(data is URLVariables)
         {
            uq.data = data;
         }
         else
         {
            uv = new URLVariables();
            for(key in data)
            {
               uv[key] = data[key];
            }
            uq.data = uv;
         }
         loadComplete = null;
         ioError = null;
         securityError = null;
         clear = null;
         clear = function():void
         {
            loader.removeEventListener(Event.COMPLETE,loadComplete);
            loader.removeEventListener(IOErrorEvent.IO_ERROR,ioError);
            loader.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,securityError);
            loader = null;
            loadComplete = null;
            ioError = null;
            securityError = null;
            clear = null;
            onComplete = null;
            onFail = null;
         };
         loadComplete = function(e:Event):void
         {
            if(onComplete != null)
            {
               onComplete(loader.data);
            }
            clear();
         };
         ioError = function(e:IOErrorEvent):void
         {
            if(showDebug)
            {
               trace("KyoURLoader.post IO_ERROR:",url,"\n",e.toString());
            }
            if(onFail != null)
            {
               onFail();
            }
            clear();
         };
         securityError = function(e:SecurityErrorEvent):void
         {
            if(showDebug)
            {
               trace("KyoURLoader.post SECURITY_ERROR:",url,"\n",e.toString());
            }
            if(onFail != null)
            {
               onFail();
            }
            clear();
         };
         loader.addEventListener(Event.COMPLETE,loadComplete);
         loader.addEventListener(IOErrorEvent.IO_ERROR,ioError);
         loader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,securityError);
         loader.load(uq);
      }
      
      public static function getFileType(bytes:ByteArray) : String
      {
         var b1:int = int(bytes.readUnsignedByte());
         var b2:int = int(bytes.readUnsignedByte());
         bytes.position = 0;
         if(b1 == 255 && b2 == 254)
         {
            return TYPE_UNICODE;
         }
         if(b1 == 254 && b2 == 255)
         {
            return TYPE_UNICODE_BIG_ENDIAN;
         }
         if(b1 == 239 && b2 == 187)
         {
            return TYPE_UTF8;
         }
         return TYPE_ANSI;
      }
   }
}


package net.play5d.kyo.loader
{
   import flash.display.Loader;
   import flash.display.LoaderInfo;
   import flash.events.Event;
   import flash.events.EventDispatcher;
   import flash.events.IOErrorEvent;
   import flash.events.ProgressEvent;
   import flash.events.SecurityErrorEvent;
   import flash.events.TimerEvent;
   import flash.net.URLRequest;
   import flash.system.ApplicationDomain;
   import flash.system.LoaderContext;
   import flash.utils.Dictionary;
   import flash.utils.Timer;
   
   public class KyoClassLoader extends EventDispatcher
   {
      
      private var _classes:Object = {};
      
      private var _urls:Array;
      
      private var _defaultId:String;
      
      private var _loadedAmount:int;
      
      private var _loadLength:int;
      
      private var _directory:Dictionary = new Dictionary(true);
      
      private var _loading:Boolean;
      
      private var _activeLoader:Loader;
      
      private var _currentUrl:String;
      
      private var _timeoutTimer:Timer;
      
      private var _retryCount:int = 0;
      
      private const MAX_RETRY:int = 3;
      
      public function KyoClassLoader()
      {
         super();
         _timeoutTimer = new Timer(15000,1);
         _timeoutTimer.addEventListener(TimerEvent.TIMER_COMPLETE,onTimeout);
      }
      
      public function getClass(className:String, swfId:String = null) : Class
      {
         swfId ||= this._defaultId;
         var app:ApplicationDomain = this._classes[swfId];
         if(!app)
         {
            throw new Error(swfId + " belum dimuat / tidak ditemukan!");
         }
         try
         {
            return app.getDefinition(className) as Class;
         }
         catch(e:Error)
         {
            throw new Error("Definisi class " + className + " tidak ditemukan di dalam " + swfId + "!");
         }
      }
      
      public function get loadedAmount() : int
      {
         return this._loadedAmount;
      }
      
      public function load(urls:Object) : void
      {
         if(this._loading)
         {
            throw new Error("Tidak dapat memanggil load() saat proses muat sebelumnya belum selesai!");
         }
         if(urls is String)
         {
            this._urls = [urls];
         }
         else if(urls is Array)
         {
            this._urls = (urls as Array).concat();
         }
         this._loadLength = this._urls.length;
         this._loadedAmount = 0;
         this._loading = true;
         this.loadNext();
      }
      
      public function addSwf(id:String, swfLoader:Loader) : void
      {
         if(!swfLoader || !swfLoader.contentLoaderInfo)
         {
            return;
         }
         this._classes[id] = swfLoader.contentLoaderInfo.applicationDomain;
         try
         {
            swfLoader.unloadAndStop(true);
         }
         catch(e:Error)
         {
            swfLoader.unload();
         }
      }
      
      private function loadNext() : Boolean
      {
         if(this._urls.length < 1)
         {
            return false;
         }
         _retryCount = 0;
         _currentUrl = this._urls.shift();
         ++this._loadedAmount;
         startLoad();
         return true;
      }
      
      private function startLoad() : void
      {
         _activeLoader = new Loader();
         var loaderContext:LoaderContext = new LoaderContext(false,ApplicationDomain.currentDomain);
         _activeLoader.contentLoaderInfo.addEventListener(Event.COMPLETE,this.loadComplete);
         _activeLoader.contentLoaderInfo.addEventListener(ProgressEvent.PROGRESS,this.loadProgress);
         _activeLoader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR,this.loadError);
         _activeLoader.contentLoaderInfo.addEventListener(SecurityErrorEvent.SECURITY_ERROR,this.loadSecurityError);
         this._directory[_activeLoader] = _currentUrl;
         _activeLoader.load(new URLRequest(_currentUrl),loaderContext);
         _timeoutTimer.reset();
         _timeoutTimer.start();
      }
      
      private function onTimeout(e:TimerEvent) : void
      {
         trace("KyoClassLoader :: Timeout saat memuat: " + _currentUrl);
         removeLoader(_activeLoader);
         ++_retryCount;
         if(_retryCount <= MAX_RETRY)
         {
            trace("KyoClassLoader :: Mencoba ulang (" + _retryCount + "/" + MAX_RETRY + ")...");
            startLoad();
         }
         else
         {
            trace("KyoClassLoader :: Gagal permanen setelah batas retry: " + _currentUrl);
            dispatchEvent(new IOErrorEvent(IOErrorEvent.IO_ERROR,false,false,"Timeout: " + _currentUrl));
            this.checkComplete();
         }
      }
      
      private function removeLoader(loader:Loader) : void
      {
         if(!loader)
         {
            return;
         }
         loader.contentLoaderInfo.removeEventListener(Event.COMPLETE,this.loadComplete);
         loader.contentLoaderInfo.removeEventListener(ProgressEvent.PROGRESS,this.loadProgress);
         loader.contentLoaderInfo.removeEventListener(IOErrorEvent.IO_ERROR,this.loadError);
         loader.contentLoaderInfo.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,this.loadSecurityError);
         try
         {
            loader.unloadAndStop(true);
         }
         catch(e:Error)
         {
            try
            {
               loader.unload();
            }
            catch(err:Error)
            {
            }
         }
      }
      
      private function loadComplete(e:Event) : void
      {
         _timeoutTimer.stop();
         var info:LoaderInfo = e.currentTarget as LoaderInfo;
         var loader:Loader = info.loader;
         var urlStr:String = this._directory[loader];
         this._defaultId = this._defaultId || urlStr;
         this._classes[urlStr] = info.applicationDomain;
         this.removeLoader(loader);
         this.checkComplete();
      }
      
      private function loadProgress(e:ProgressEvent) : void
      {
         _timeoutTimer.reset();
         _timeoutTimer.start();
         dispatchEvent(e);
      }
      
      private function loadError(e:IOErrorEvent) : void
      {
         _timeoutTimer.stop();
         var loader:Loader = (e.currentTarget as LoaderInfo).loader;
         trace("KyoClassLoader.loadError :: Gagal memuat " + _currentUrl);
         this.removeLoader(loader);
         dispatchEvent(e);
         this.checkComplete();
      }
      
      private function loadSecurityError(e:SecurityErrorEvent) : void
      {
         _timeoutTimer.stop();
         var loader:Loader = (e.currentTarget as LoaderInfo).loader;
         trace("KyoClassLoader.loadSecurityError :: Masalah CORS/Sandbox pada " + _currentUrl);
         this.removeLoader(loader);
         dispatchEvent(new IOErrorEvent(IOErrorEvent.IO_ERROR,false,false,"Security Error: " + _currentUrl));
         this.checkComplete();
      }
      
      private function checkComplete() : void
      {
         _activeLoader = null;
         if(this.loadNext() == false)
         {
            this._loading = false;
            dispatchEvent(new Event(Event.COMPLETE));
         }
      }
   }
}


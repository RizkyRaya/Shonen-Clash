package net.play5d.kyo.loader
{
   import flash.display.Bitmap;
   import flash.display.Loader;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.SecurityErrorEvent;
   import flash.net.URLRequest;
   
   public class BitmapLoader
   {
      
      public var bitmap:Bitmap;
      
      public var url:String;
      
      public function BitmapLoader()
      {
         super();
      }
      
      public function load(urlPath:String, onComplete:Function = null, onFail:Function = null) : void
      {
         var loader:Loader;
         var loadComplete:Function;
         var loadFail:Function;
         this.url = urlPath;
         loader = new Loader();
         loadComplete = null;
         loadFail = null;
         loadComplete = function(e:Event):void
         {
            if(loader && loader.content)
            {
               bitmap = loader.content as Bitmap;
            }
            loader.contentLoaderInfo.removeEventListener(Event.COMPLETE,loadComplete);
            loader.contentLoaderInfo.removeEventListener(IOErrorEvent.IO_ERROR,loadFail);
            loader.contentLoaderInfo.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,loadFail);
            loader.unload();
            loader = null;
            if(onComplete != null)
            {
               onComplete(bitmap);
            }
            loadComplete = null;
            loadFail = null;
            onComplete = null;
            onFail = null;
         };
         loadFail = function(e:Event):void
         {
            loader.contentLoaderInfo.removeEventListener(Event.COMPLETE,loadComplete);
            loader.contentLoaderInfo.removeEventListener(IOErrorEvent.IO_ERROR,loadFail);
            loader.contentLoaderInfo.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,loadFail);
            loader.unload();
            loader = null;
            if(onFail != null)
            {
               onFail();
            }
            loadComplete = null;
            loadFail = null;
            onComplete = null;
            onFail = null;
         };
         loader.contentLoaderInfo.addEventListener(Event.COMPLETE,loadComplete);
         loader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR,loadFail);
         loader.contentLoaderInfo.addEventListener(SecurityErrorEvent.SECURITY_ERROR,loadFail);
         loader.load(new URLRequest(urlPath));
      }
   }
}


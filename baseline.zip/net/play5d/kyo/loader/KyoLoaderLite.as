package net.play5d.kyo.loader
{
   import flash.display.DisplayObject;
   import flash.display.Loader;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.ProgressEvent;
   import flash.events.SecurityErrorEvent;
   import flash.net.URLLoader;
   import flash.net.URLLoaderDataFormat;
   import flash.net.URLRequest;
   import flash.system.ApplicationDomain;
   import flash.system.LoaderContext;
   import flash.utils.ByteArray;
   
   public class KyoLoaderLite
   {
      
      public function KyoLoaderLite()
      {
         super();
      }
      
      public static function load(url:String, onComplete:Function, onFail:Function = null, onProcess:Function = null) : void
      {
         var ctx:LoaderContext;
         var l:Loader = new Loader();
         var loadComplete:Function = null;
         var ioError:Function = null;
         var securityError:Function = null;
         var progressHandler:Function = null;
         var clear:Function = null;
         clear = function(isError:Boolean = false):void
         {
            if(l == null)
            {
               return;
            }
            l.contentLoaderInfo.removeEventListener(Event.COMPLETE,loadComplete);
            l.contentLoaderInfo.removeEventListener(IOErrorEvent.IO_ERROR,ioError);
            l.contentLoaderInfo.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,securityError);
            l.contentLoaderInfo.removeEventListener(ProgressEvent.PROGRESS,progressHandler);
            if(isError)
            {
               try
               {
                  l.unloadAndStop(false);
               }
               catch(e:Error)
               {
                  l.unload();
               }
            }
            l = null;
            loadComplete = null;
            ioError = null;
            securityError = null;
            progressHandler = null;
            clear = null;
            onComplete = null;
            onFail = null;
            onProcess = null;
         };
         loadComplete = function(e:Event):void
         {
            var content:DisplayObject = l.content;
            if(onComplete != null)
            {
               onComplete(content);
            }
            clear(false);
         };
         ioError = function(e:IOErrorEvent):void
         {
            trace("KyoLoaderLite.load IO_ERROR:",url);
            if(onFail != null)
            {
               onFail();
            }
            clear(true);
         };
         securityError = function(e:SecurityErrorEvent):void
         {
            trace("KyoLoaderLite.load SECURITY_ERROR:",url);
            if(onFail != null)
            {
               onFail();
            }
            clear(true);
         };
         progressHandler = function(e:ProgressEvent):void
         {
            if(onProcess != null)
            {
               onProcess(e.bytesLoaded / e.bytesTotal);
            }
         };
         l.contentLoaderInfo.addEventListener(Event.COMPLETE,loadComplete);
         l.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR,ioError);
         l.contentLoaderInfo.addEventListener(SecurityErrorEvent.SECURITY_ERROR,securityError);
         l.contentLoaderInfo.addEventListener(ProgressEvent.PROGRESS,progressHandler);
         ctx = new LoaderContext(false,new ApplicationDomain(ApplicationDomain.currentDomain));
         ctx.allowCodeImport = true;
         l.load(new URLRequest(url),ctx);
      }
      
      public static function loadLoader(url:String, onComplete:Function, onFail:Function = null, onProcess:Function = null) : void
      {
         var ctx:LoaderContext;
         var l:Loader = new Loader();
         var loadComplete:Function = null;
         var ioError:Function = null;
         var securityError:Function = null;
         var progressHandler:Function = null;
         var clear:Function = null;
         clear = function():void
         {
            if(l == null)
            {
               return;
            }
            l.contentLoaderInfo.removeEventListener(Event.COMPLETE,loadComplete);
            l.contentLoaderInfo.removeEventListener(IOErrorEvent.IO_ERROR,ioError);
            l.contentLoaderInfo.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,securityError);
            l.contentLoaderInfo.removeEventListener(ProgressEvent.PROGRESS,progressHandler);
            loadComplete = null;
            ioError = null;
            securityError = null;
            progressHandler = null;
            clear = null;
            onComplete = null;
            onFail = null;
            onProcess = null;
         };
         loadComplete = function(e:Event):void
         {
            if(onComplete != null)
            {
               onComplete(l);
            }
            clear();
         };
         ioError = function(e:IOErrorEvent):void
         {
            trace("KyoLoaderLite.loadLoader IO_ERROR:",url);
            if(onFail != null)
            {
               onFail();
            }
            clear();
         };
         securityError = function(e:SecurityErrorEvent):void
         {
            trace("KyoLoaderLite.loadLoader SECURITY_ERROR:",url);
            if(onFail != null)
            {
               onFail();
            }
            clear();
         };
         progressHandler = function(e:ProgressEvent):void
         {
            if(onProcess != null)
            {
               onProcess(e.bytesLoaded / e.bytesTotal);
            }
         };
         l.contentLoaderInfo.addEventListener(Event.COMPLETE,loadComplete);
         l.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR,ioError);
         l.contentLoaderInfo.addEventListener(SecurityErrorEvent.SECURITY_ERROR,securityError);
         l.contentLoaderInfo.addEventListener(ProgressEvent.PROGRESS,progressHandler);
         ctx = new LoaderContext(false,new ApplicationDomain(ApplicationDomain.currentDomain));
         ctx.allowCodeImport = true;
         l.load(new URLRequest(url),ctx);
      }
      
      public static function loadBytes(url:String, onComplete:Function, onFail:Function = null, onProcess:Function = null) : void
      {
         var loadComplete:Function;
         var ioError:Function;
         var securityError:Function;
         var progressHandler:Function;
         var clear:Function;
         var loader:URLLoader = new URLLoader();
         loader.dataFormat = URLLoaderDataFormat.BINARY;
         loadComplete = null;
         ioError = null;
         securityError = null;
         progressHandler = null;
         clear = null;
         clear = function():void
         {
            loader.removeEventListener(Event.COMPLETE,loadComplete);
            loader.removeEventListener(IOErrorEvent.IO_ERROR,ioError);
            loader.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,securityError);
            loader.removeEventListener(ProgressEvent.PROGRESS,progressHandler);
            loader = null;
            loadComplete = null;
            ioError = null;
            securityError = null;
            progressHandler = null;
            clear = null;
            onComplete = null;
            onFail = null;
            onProcess = null;
         };
         loadComplete = function(e:Event):void
         {
            if(onComplete != null)
            {
               onComplete(loader.data as ByteArray);
            }
            clear();
         };
         ioError = function(e:IOErrorEvent):void
         {
            trace("KyoLoaderLite.loadBytes IO_ERROR:",url);
            if(onFail != null)
            {
               onFail();
            }
            clear();
         };
         securityError = function(e:SecurityErrorEvent):void
         {
            trace("KyoLoaderLite.loadBytes SECURITY_ERROR:",url);
            if(onFail != null)
            {
               onFail();
            }
            clear();
         };
         progressHandler = function(e:ProgressEvent):void
         {
            if(onProcess != null)
            {
               onProcess(e.bytesLoaded / e.bytesTotal);
            }
         };
         loader.addEventListener(Event.COMPLETE,loadComplete);
         loader.addEventListener(IOErrorEvent.IO_ERROR,ioError);
         loader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,securityError);
         loader.addEventListener(ProgressEvent.PROGRESS,progressHandler);
         loader.load(new URLRequest(url));
      }
      
      public static function bytesToDisplay(bytes:ByteArray, onComplete:Function = null, onFail:Function = null) : Loader
      {
         var ctx:LoaderContext;
         var loader:Loader = new Loader();
         var onLoadComplete:Function = null;
         var onLoadError:Function = null;
         var clear:Function = null;
         clear = function():void
         {
            loader.contentLoaderInfo.removeEventListener(Event.COMPLETE,onLoadComplete);
            loader.contentLoaderInfo.removeEventListener(IOErrorEvent.IO_ERROR,onLoadError);
            loader.contentLoaderInfo.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,onLoadError);
            onLoadComplete = null;
            onLoadError = null;
            clear = null;
            onComplete = null;
            onFail = null;
         };
         onLoadComplete = function(e:Event):void
         {
            if(onComplete != null)
            {
               onComplete(loader);
            }
            clear();
         };
         onLoadError = function(e:Event):void
         {
            trace("KyoLoaderLite.bytesToDisplay ERROR:",e.type);
            if(onFail != null)
            {
               onFail();
            }
            clear();
         };
         loader.contentLoaderInfo.addEventListener(Event.COMPLETE,onLoadComplete);
         loader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR,onLoadError);
         loader.contentLoaderInfo.addEventListener(SecurityErrorEvent.SECURITY_ERROR,onLoadError);
         ctx = new LoaderContext(false,new ApplicationDomain(ApplicationDomain.currentDomain));
         ctx.allowCodeImport = true;
         loader.loadBytes(bytes,ctx);
         return loader;
      }
   }
}


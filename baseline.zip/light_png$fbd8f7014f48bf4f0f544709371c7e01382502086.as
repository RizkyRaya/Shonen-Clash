package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/12_light_png$fbd8f7014f48bf4f0f544709371c7e01382502086.png")]
   public class light_png$fbd8f7014f48bf4f0f544709371c7e01382502086 extends Bitmap
   {
      
      public function light_png$fbd8f7014f48bf4f0f544709371c7e01382502086()
      {
         super();
      }
   }
}


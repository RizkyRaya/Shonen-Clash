package
{
   import flash.desktop.NativeApplication;
   import flash.desktop.SystemIdleMode;
   import flash.display.Bitmap;
   import flash.display.Loader;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.KeyboardEvent;
   import flash.events.UncaughtErrorEvent;
   import flash.filesystem.File;
   import flash.filesystem.FileMode;
   import flash.filesystem.FileStream;
   import flash.system.ApplicationDomain;
   import flash.system.LoaderContext;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import net.play5d.game.bvn.GameConfig;
   import net.play5d.game.bvn.data.GameData;
   import net.play5d.game.bvn.events.GameEvent;
   import net.play5d.game.bvn.interfaces.GameInterface;
   import net.play5d.game.bvn.mob.GameInterfaceManager;
   import net.play5d.game.bvn.mob.RootSprite;
   import net.play5d.game.bvn.mob.ctrls.ControllerHudManager;
   import net.play5d.game.bvn.mob.ctrls.GamePolyCtrl;
   import net.play5d.game.bvn.mob.ctrls.MobileCtrler;
   import net.play5d.game.bvn.mob.ctrls.UpdateCtrl;
   import net.play5d.game.bvn.mob.screenpad.ScreenPadManager;
   import net.play5d.game.bvn.mob.utils.TimerOutUtils;
   import net.play5d.game.bvn.mob.utils.UIAssetUtil;
   import net.play5d.game.bvn.ui.GameUI;
   import net.play5d.game.bvn.ui.UIUtils;
   import net.play5d.game.bvn.ui.fight.FightUI;
   import net.play5d.game.bvn.utils.URL;
   
   public class launchWUFAN extends Sprite
   {
      
      public static const VERSION_CODE:int = 100;
      
      private var startupBitmap:Class = §startup_png$c61762f6f9411650a4e1676ff4fb42b4-566676444§;
      
      private var _startBitmap:Bitmap;
      
      private var _sdkTimer:int;
      
      private var _isActive:Boolean = true;
      
      private var _preInited:Boolean = false;
      
      private var _debugLog:TextField;
      
      public function launchWUFAN()
      {
         super();
         if(stage != null)
         {
            initlize();
         }
         else
         {
            addEventListener("addedToStage",initlize);
         }
      }
      
      private function initlize(param1:Event = null) : void
      {
         removeEventListener("addedToStage",initlize);
         stage.align = "TL";
         stage.scaleMode = "noScale";
         try
         {
            NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.KEEP_AWAKE;
         }
         catch(e:Error)
         {
            sendLog("KEEP_AWAKE Error: " + e.message);
         }
         GameConfig.TOUCH_MODE = true;
         setupDebugger();
         try
         {
            if(File.documentsDirectory.permissionStatus != "granted")
            {
               File.documentsDirectory.requestPermission();
            }
         }
         catch(e:Error)
         {
         }
         checkAndLoadExternal();
      }
      
      private function setupDebugger() : void
      {
         _debugLog = new TextField();
         var fmt:TextFormat = new TextFormat();
         fmt.size = 24;
         fmt.color = 65280;
         fmt.bold = true;
         _debugLog.defaultTextFormat = fmt;
         _debugLog.width = 1200;
         _debugLog.height = 800;
         _debugLog.wordWrap = true;
         _debugLog.multiline = true;
         _debugLog.mouseEnabled = false;
      }
      
      private function sendLog(msg:String) : void
      {
         trace(msg);
      }
      
      private function checkAndLoadExternal() : void
      {
         var externalFile:File;
         var _loader:Loader;
         var context:LoaderContext;
         var fileStream:FileStream;
         var bytes:ByteArray;
         var externalDir:File;
         try
         {
            externalDir = new File("/storage/emulated/0/assets/update");
            if(!externalDir.exists)
            {
               externalDir.createDirectory();
            }
            externalFile = externalDir.resolvePath("launchWUFAN.swf");
            if(externalFile.exists)
            {
               sendLog("Update Found! Size: " + externalFile.size + " bytes");
               _loader = new Loader();
               context = new LoaderContext(false,new ApplicationDomain());
               context.allowCodeImport = true;
               context.allowLoadBytesCodeExecution = true;
               _loader.uncaughtErrorEvents.addEventListener(UncaughtErrorEvent.UNCAUGHT_ERROR,function(e:UncaughtErrorEvent):void
               {
                  e.preventDefault();
               });
               _loader.contentLoaderInfo.addEventListener(Event.COMPLETE,function(e:Event):void
               {
                  var extDomain:ApplicationDomain;
                  var extVersion:int;
                  var extClass:Class;
                  try
                  {
                     extDomain = _loader.contentLoaderInfo.applicationDomain;
                     extVersion = 0;
                     if(extDomain && extDomain.hasDefinition("launchWUFAN"))
                     {
                        extClass = extDomain.getDefinition("launchWUFAN") as Class;
                        if(extClass && extClass["VERSION_CODE"] != undefined)
                        {
                           extVersion = int(extClass["VERSION_CODE"]);
                        }
                     }
                     sendLog("Patch Version: " + extVersion + " | Base Version: " + VERSION_CODE);
                     if(extVersion >= VERSION_CODE)
                     {
                        addChild(_loader);
                     }
                     else
                     {
                        _loader.unloadAndStop();
                        startGame();
                     }
                  }
                  catch(err:Error)
                  {
                     sendLog("ERROR CHECK VERSION: " + err.message);
                     _loader.unloadAndStop();
                     startGame();
                  }
               });
               _loader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR,function(e:IOErrorEvent):void
               {
                  startGame();
               });
               try
               {
                  fileStream = new FileStream();
                  bytes = new ByteArray();
                  fileStream.open(externalFile,FileMode.READ);
                  fileStream.readBytes(bytes);
                  fileStream.close();
                  _loader.loadBytes(bytes,context);
               }
               catch(fsErr:Error)
               {
                  sendLog("ERROR READING FILE: " + fsErr.message);
                  startGame();
               }
            }
            else
            {
               startGame();
            }
         }
         catch(dirError:Error)
         {
            sendLog("DIR PERMISSION ERROR: " + dirError.message);
            startGame();
         }
      }
      
      private function startGame() : void
      {
         if(_debugLog && contains(_debugLog))
         {
            removeChild(_debugLog);
         }
         showStartPic();
         initSDK();
      }
      
      private function showStartPic() : void
      {
         RootSprite.STAGE = stage;
         RootSprite.I.init(this);
         RootSprite.I.updateFullScreenSize();
         stage.addEventListener("deactivate",activeHandler);
         stage.addEventListener("activate",activeHandler);
         try
         {
            if(startupBitmap != null)
            {
               _startBitmap = new startupBitmap();
               _startBitmap.width = RootSprite.FULL_SCREEN_SIZE.x;
               _startBitmap.height = RootSprite.FULL_SCREEN_SIZE.y;
               addChild(_startBitmap);
            }
         }
         catch(e:Error)
         {
         }
      }
      
      private function initSDK() : void
      {
         preInitGame();
         initGame();
      }
      
      private function sdkBack() : void
      {
      }
      
      private function adBack() : void
      {
      }
      
      private function preInitGame() : void
      {
         if(_preInited)
         {
            return;
         }
         _preInited = true;
      }
      
      private function removeStartBitmap() : void
      {
         if(_startBitmap)
         {
            try
            {
               removeChild(_startBitmap);
            }
            catch(e:Error)
            {
            }
            try
            {
               _startBitmap.bitmapData.dispose();
            }
            catch(e:Error)
            {
            }
            _startBitmap = null;
         }
      }
      
      private function initGame() : void
      {
         preInitGame();
         removeStartBitmap();
         stage.addEventListener("keyDown",keyHandler);
         stage.addEventListener("resize",RootSprite.I.updateFullScreenSize);
         GameInterface.instance = new GameInterfaceManager();
         GameData.I.config.AI_level = 4;
         GameData.I.config.quality = "low";
         GameData.I.config.keyInputMode = 1;
         GameConfig.SHOW_HOW_TO_PLAY = false;
         UIUtils.LOCK_FONT = "Droid Sans Fallback";
         URL.MARK = "bvn_mobV3.7";
         ScreenPadManager.initlize(stage);
         initUI();
      }
      
      private function initUI() : void
      {
         UIAssetUtil.I.initalize(initGameConfig);
      }
      
      private function englishVersion() : void
      {
         GameUI.SHOW_CN_TEXT = false;
         GameInterfaceManager.ENGLISH_VERSION = true;
      }
      
      private function activeHandler(param1:Event) : void
      {
         if(param1.type == "deactivate")
         {
            if(!_isActive)
            {
               return;
            }
            _isActive = false;
            try
            {
               NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.NORMAL;
            }
            catch(e:Error)
            {
            }
            TimerOutUtils.pauseAllTimer();
            MobileCtrler.I.pause();
         }
         else
         {
            if(_isActive)
            {
               return;
            }
            _isActive = true;
            try
            {
               NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.KEEP_AWAKE;
            }
            catch(e:Error)
            {
            }
            TimerOutUtils.resumeAllTimer();
            MobileCtrler.I.resume();
         }
      }
      
      private function keyHandler(param1:KeyboardEvent) : void
      {
         if(param1.keyCode == 16777238)
         {
            param1.preventDefault();
         }
      }
      
      private function initGameConfig() : void
      {
         var _loc1_:Array = ["http://1212321.cn-sh2.ufileos.com/upload/BVN_WF.ini","http://1212321.com/file/get/BVN_WF.ini"];
         GamePolyCtrl.I.loadConfig(_loc1_,gamePolyComplete);
      }
      
      private function gamePolyComplete() : void
      {
         buildGame();
      }
      
      private function gameEventHandler(param1:GameEvent) : Boolean
      {
         return false;
      }
      
      private function buildGame() : void
      {
         RootSprite.I.buildGame(initBackHandler,initFailHandler);
         GameEvent.addEventListener("ENTER_SINGLE_STAGE",enterStageHandler);
         GameEvent.addEventListener("ENTER_TEAM_STAGE",enterStageHandler);
         GameEvent.addEventListener("ENTER_TRAIN_STAGE",enterStageHandler);
         GameEvent.addEventListener("ENTER_MOSOU_STAGE",enterStageHandler);
      }
      
      private function enterStageHandler(param1:GameEvent) : void
      {
      }
      
      private function initBackHandler() : void
      {
         ScreenPadManager.listen();
         ControllerHudManager.start();
         FightUI.QI_BAR_MODE = 1;
         UpdateCtrl.I.update(updateBack,updateBack);
      }
      
      private function updateBack() : void
      {
         RootSprite.I.getMainGame().goLogo();
      }
      
      private function initFailHandler(param1:String) : void
      {
         NativeApplication.nativeApplication.exit();
      }
   }
}


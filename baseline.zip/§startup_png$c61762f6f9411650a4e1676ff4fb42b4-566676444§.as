package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/1_startup_png$c61762f6f9411650a4e1676ff4fb42b4-566676444.jpg")]
   public class §startup_png$c61762f6f9411650a4e1676ff4fb42b4-566676444§ extends Bitmap
   {
      
      public function §startup_png$c61762f6f9411650a4e1676ff4fb42b4-566676444§()
      {
         super();
      }
   }
}


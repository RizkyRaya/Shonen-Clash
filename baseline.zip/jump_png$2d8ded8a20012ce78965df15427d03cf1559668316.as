package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/10_jump_png$2d8ded8a20012ce78965df15427d03cf1559668316.png")]
   public class jump_png$2d8ded8a20012ce78965df15427d03cf1559668316 extends Bitmap
   {
      
      public function jump_png$2d8ded8a20012ce78965df15427d03cf1559668316()
      {
         super();
      }
   }
}


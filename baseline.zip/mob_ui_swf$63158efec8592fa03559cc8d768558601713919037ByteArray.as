package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/2_mob_ui_swf$63158efec8592fa03559cc8d768558601713919037ByteArray.bin", mimeType="application/octet-stream")]
   public class mob_ui_swf$63158efec8592fa03559cc8d768558601713919037ByteArray extends ByteArray
   {
      
      public function mob_ui_swf$63158efec8592fa03559cc8d768558601713919037ByteArray()
      {
         super();
      }
   }
}


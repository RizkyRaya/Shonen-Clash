package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/11_skill2_png$e24713ac015a2dc03140ca1048abe529266689519.png")]
   public class skill2_png$e24713ac015a2dc03140ca1048abe529266689519 extends Bitmap
   {
      
      public function skill2_png$e24713ac015a2dc03140ca1048abe529266689519()
      {
         super();
      }
   }
}


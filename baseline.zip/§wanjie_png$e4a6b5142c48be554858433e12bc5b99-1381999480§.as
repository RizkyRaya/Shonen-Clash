package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/9_wanjie_png$e4a6b5142c48be554858433e12bc5b99-1381999480.png")]
   public class §wanjie_png$e4a6b5142c48be554858433e12bc5b99-1381999480§ extends Bitmap
   {
      
      public function §wanjie_png$e4a6b5142c48be554858433e12bc5b99-1381999480§()
      {
         super();
      }
   }
}


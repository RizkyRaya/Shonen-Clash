package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/13_jump2_png$7b37176eeab785dc3e8410d6a5e77f4b427807092.png")]
   public class jump2_png$7b37176eeab785dc3e8410d6a5e77f4b427807092 extends Bitmap
   {
      
      public function jump2_png$7b37176eeab785dc3e8410d6a5e77f4b427807092()
      {
         super();
      }
   }
}


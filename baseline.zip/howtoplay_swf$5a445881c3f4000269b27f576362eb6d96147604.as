package
{
   import flash.compiler.embed.EmbeddedMovieClip;
   
   public class howtoplay_swf$5a445881c3f4000269b27f576362eb6d96147604 extends EmbeddedMovieClip
   {
      
      public function howtoplay_swf$5a445881c3f4000269b27f576362eb6d96147604()
      {
         super(new howtoplay_swf$5a445881c3f4000269b27f576362eb6d96147604ByteArray(),800,600);
      }
   }
}


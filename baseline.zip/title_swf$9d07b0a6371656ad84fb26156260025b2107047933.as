package
{
   import flash.compiler.embed.EmbeddedMovieClip;
   
   public class title_swf$9d07b0a6371656ad84fb26156260025b2107047933 extends EmbeddedMovieClip
   {
      
      public function title_swf$9d07b0a6371656ad84fb26156260025b2107047933()
      {
         super(new title_swf$9d07b0a6371656ad84fb26156260025b2107047933ByteArray(),800,600);
      }
   }
}


package
{
   import flash.compiler.embed.EmbeddedMovieClip;
   
   public class loading_swf$05a8dab2aa9490e41daf78e885c1980c976431505 extends EmbeddedMovieClip
   {
      
      public function loading_swf$05a8dab2aa9490e41daf78e885c1980c976431505()
      {
         super(new loading_swf$05a8dab2aa9490e41daf78e885c1980c976431505ByteArray(),800,600);
      }
   }
}


include "fight_swf$162e2455ccbf20b451f988a3b726b095786794501ByteArray.as";
include "fight_swf$162e2455ccbf20b451f988a3b726b095786794501.as";


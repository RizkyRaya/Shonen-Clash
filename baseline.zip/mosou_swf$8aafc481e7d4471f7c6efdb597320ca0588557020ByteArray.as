package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/29_mosou_swf$8aafc481e7d4471f7c6efdb597320ca0588557020ByteArray.bin", mimeType="application/octet-stream")]
   public class mosou_swf$8aafc481e7d4471f7c6efdb597320ca0588557020ByteArray extends ByteArray
   {
      
      public function mosou_swf$8aafc481e7d4471f7c6efdb597320ca0588557020ByteArray()
      {
         super();
      }
   }
}


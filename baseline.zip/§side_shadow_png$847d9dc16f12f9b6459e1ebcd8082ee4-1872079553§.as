package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/4_side_shadow_png$847d9dc16f12f9b6459e1ebcd8082ee4-1872079553.png")]
   public class §side_shadow_png$847d9dc16f12f9b6459e1ebcd8082ee4-1872079553§ extends Bitmap
   {
      
      public function §side_shadow_png$847d9dc16f12f9b6459e1ebcd8082ee4-1872079553§()
      {
         super();
      }
   }
}


package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/14_special_png$41af7aab71d15a5629fc9ea42d383f6797386273.png")]
   public class special_png$41af7aab71d15a5629fc9ea42d383f6797386273 extends Bitmap
   {
      
      public function special_png$41af7aab71d15a5629fc9ea42d383f6797386273()
      {
         super();
      }
   }
}


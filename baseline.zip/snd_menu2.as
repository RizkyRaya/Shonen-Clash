package
{
   import flash.media.Sound;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol35")]
   public dynamic class snd_menu2 extends Sound
   {
      
      public function snd_menu2()
      {
         super();
      }
   }
}


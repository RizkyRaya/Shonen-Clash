package
{
   import flash.media.Sound;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol34")]
   public dynamic class snd_menu1 extends Sound
   {
      
      public function snd_menu1()
      {
         super();
      }
   }
}


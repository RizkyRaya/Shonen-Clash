package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/21_ok_png$8b675b4fc6e5d6f0e008b86fd20bfae1-1641163214.png")]
   public class §ok_png$8b675b4fc6e5d6f0e008b86fd20bfae1-1641163214§ extends Bitmap
   {
      
      public function §ok_png$8b675b4fc6e5d6f0e008b86fd20bfae1-1641163214§()
      {
         super();
      }
   }
}


package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/25_fight_swf$162e2455ccbf20b451f988a3b726b095786794501ByteArray.bin", mimeType="application/octet-stream")]
   public class fight_swf$162e2455ccbf20b451f988a3b726b095786794501ByteArray extends ByteArray
   {
      
      public function fight_swf$162e2455ccbf20b451f988a3b726b095786794501ByteArray()
      {
         super();
      }
   }
}


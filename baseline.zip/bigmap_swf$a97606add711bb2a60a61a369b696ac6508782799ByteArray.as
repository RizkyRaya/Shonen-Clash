package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/22_bigmap_swf$a97606add711bb2a60a61a369b696ac6508782799ByteArray.bin", mimeType="application/octet-stream")]
   public class bigmap_swf$a97606add711bb2a60a61a369b696ac6508782799ByteArray extends ByteArray
   {
      
      public function bigmap_swf$a97606add711bb2a60a61a369b696ac6508782799ByteArray()
      {
         super();
      }
   }
}


package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/23_common_ui_swf$fa8c50f0c229a548cd53218b6f64f0d9-2091959187ByteArray.bin", mimeType="application/octet-stream")]
   public class §common_ui_swf$fa8c50f0c229a548cd53218b6f64f0d9-2091959187ByteArray§ extends ByteArray
   {
      
      public function §common_ui_swf$fa8c50f0c229a548cd53218b6f64f0d9-2091959187ByteArray§()
      {
         super();
      }
   }
}


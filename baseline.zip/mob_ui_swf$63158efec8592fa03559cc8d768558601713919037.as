package
{
   import flash.compiler.embed.EmbeddedMovieClip;
   
   public class mob_ui_swf$63158efec8592fa03559cc8d768558601713919037 extends EmbeddedMovieClip
   {
      
      public function mob_ui_swf$63158efec8592fa03559cc8d768558601713919037()
      {
         super(new mob_ui_swf$63158efec8592fa03559cc8d768558601713919037ByteArray(),800,600);
      }
   }
}


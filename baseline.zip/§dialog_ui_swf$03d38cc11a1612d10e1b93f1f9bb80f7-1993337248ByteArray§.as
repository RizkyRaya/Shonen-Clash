package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/24_dialog_ui_swf$03d38cc11a1612d10e1b93f1f9bb80f7-1993337248ByteArray.bin", mimeType="application/octet-stream")]
   public class §dialog_ui_swf$03d38cc11a1612d10e1b93f1f9bb80f7-1993337248ByteArray§ extends ByteArray
   {
      
      public function §dialog_ui_swf$03d38cc11a1612d10e1b93f1f9bb80f7-1993337248ByteArray§()
      {
         super();
      }
   }
}


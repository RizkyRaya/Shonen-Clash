package
{
   import flash.compiler.embed.EmbeddedMovieClip;
   
   public class fight_swf$162e2455ccbf20b451f988a3b726b095786794501 extends EmbeddedMovieClip
   {
      
      public function fight_swf$162e2455ccbf20b451f988a3b726b095786794501()
      {
         super(new fight_swf$162e2455ccbf20b451f988a3b726b095786794501ByteArray(),800,600);
      }
   }
}

